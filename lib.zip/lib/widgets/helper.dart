import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';



class Helper {
  static void checkStatus() {
    // final userStatusController = Get.put(UserStatusController());
  }
}
